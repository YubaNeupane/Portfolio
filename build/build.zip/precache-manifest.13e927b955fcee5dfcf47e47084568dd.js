self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "67906c6cfdb41b7fc615aacd0f706fd1",
    "url": "/index.html"
  },
  {
    "revision": "9691e29cfdfcfceaf5ca",
    "url": "/static/css/2.242f24fe.chunk.css"
  },
  {
    "revision": "32c8b1122ac74e8ef4c8",
    "url": "/static/css/main.b55b150e.chunk.css"
  },
  {
    "revision": "9691e29cfdfcfceaf5ca",
    "url": "/static/js/2.32254614.chunk.js"
  },
  {
    "revision": "db02dcce0f8735323c2b99800822c7f6",
    "url": "/static/js/2.32254614.chunk.js.LICENSE"
  },
  {
    "revision": "32c8b1122ac74e8ef4c8",
    "url": "/static/js/main.7fa3d40c.chunk.js"
  },
  {
    "revision": "c0d7c58e510620f2f64c",
    "url": "/static/js/runtime-main.7b61e083.js"
  },
  {
    "revision": "05a4d63183bbfed7ffa7e438926b91fe",
    "url": "/static/media/BotsIQLending.05a4d631.png"
  },
  {
    "revision": "114ea5ed8a4972119dd916a5f5ae6387",
    "url": "/static/media/GobalAvgTempChange.114ea5ed.png"
  },
  {
    "revision": "a357824529f9d266dfcc11ca8ccf20cb",
    "url": "/static/media/HeyHey.a3578245.png"
  },
  {
    "revision": "f78223b3b6da326d6721e4a3977da7cc",
    "url": "/static/media/HeyHey.f78223b3.gif"
  },
  {
    "revision": "b9e018c5d267293357f07d73b9a95428",
    "url": "/static/media/LunarLander.b9e018c5.png"
  },
  {
    "revision": "e23de053b982292322b6a66a6ffe54b5",
    "url": "/static/media/LunarLander.e23de053.gif"
  },
  {
    "revision": "0ca672961f3420e29483b03277e447a3",
    "url": "/static/media/StormBreaker.0ca67296.png"
  },
  {
    "revision": "5729228a145c48b1423a7bff684d6dc5",
    "url": "/static/media/botIqLending.5729228a.gif"
  },
  {
    "revision": "3f6996bafddb70015425190caeabd29d",
    "url": "/static/media/covid19Tracker.3f6996ba.png"
  },
  {
    "revision": "429b7f02a21292090c05620323772912",
    "url": "/static/media/covid19Tracker.429b7f02.gif"
  },
  {
    "revision": "67af05e12311bac06327b43ca31e166b",
    "url": "/static/media/earth.67af05e1.jpg"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "acf3dcb7ff752b5296ca23ba2c7c2606",
    "url": "/static/media/fontawesome-webfont.acf3dcb7.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "05acfdb568b3df49ad31355b19495d4a",
    "url": "/static/media/ionicons.05acfdb5.woff"
  },
  {
    "revision": "24712f6c47821394fba7942fbb52c3b2",
    "url": "/static/media/ionicons.24712f6c.ttf"
  },
  {
    "revision": "2c2ae068be3b089e0a5b59abb1831550",
    "url": "/static/media/ionicons.2c2ae068.eot"
  },
  {
    "revision": "c037dbbc0e6790f30e824a50010df5fb",
    "url": "/static/media/ionicons.c037dbbc.svg"
  },
  {
    "revision": "a87d0836caa0b48e541d80516f321d06",
    "url": "/static/media/issTracking.a87d0836.gif"
  },
  {
    "revision": "1567dce9040b0c1cf5bde4643e86d56e",
    "url": "/static/media/issTrackingThumbnail.1567dce9.jpg"
  },
  {
    "revision": "87cccce116563f82c5927d3d06b88efa",
    "url": "/static/media/male.87cccce1.png"
  },
  {
    "revision": "be2eb4eb89c91f609367c45f821e38bf",
    "url": "/static/media/male1.be2eb4eb.png"
  },
  {
    "revision": "3f27d46e7ac5cdcfa96d58c9bc7ec898",
    "url": "/static/media/movieSearch.3f27d46e.png"
  },
  {
    "revision": "bb92da0365903e48d47bc3c34f5fddb1",
    "url": "/static/media/movieSearchGif.bb92da03.gif"
  },
  {
    "revision": "bd80794fddbffb4031fab537cc898680",
    "url": "/static/media/myImage.bd80794f.png"
  }
]);